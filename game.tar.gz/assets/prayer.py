"""Monastery visit and a personalized prayer illustration."""

import math

from lisbon_landmarks import LANDMARKS

def at_monastery(town):
    left, top, right, bottom = LANDMARKS[0].bounds
    # The monastery is solid scenery. Its public entrance is on the south side.
    return math.hypot(town.x - (left + right) / 2, town.y - (bottom + 16)) <= 40

