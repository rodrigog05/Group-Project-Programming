"""Scrollable world, retained ambient actors and a small navigation map."""

from dataclasses import dataclass

import math

from pathlib import Path

import random

import sys

import time

from types import SimpleNamespace

from lisbon_scene import (LisbonScene, WORLD_WIDTH, WORLD_BOTTOM, RIVER_TOP, RIVER_BOTTOM,
                          bridge_center, draw_character, SOUTH_PARK_BOUNDS, SOUTH_SHIFT, south)

from lisbon_landmarks import LANDMARKS

from wayfinding import STAGES, site_guide

from guidance import compass, next_step

from ferry import FERRY_PIERS, nearby_pier

from vehicles import CAR_SPEED_RANGE, ROAD_EXCLUSIONS, in_tunnel, tunnel_covers_y

WORLD_TOP = 104

STATUS_LABEL_RADIUS = 360

def status_label_visible(camera, player_x, player_y, site, guided_name=None):
    """Detailed trade figures follow nearby places; baked purpose signs stay visible."""
    x, y = site.x+88, site.y+100
    return camera.sees(x, y, 140) and (
        site.name == guided_name or (x-player_x)**2+(y-player_y)**2 <= STATUS_LABEL_RADIUS**2
    )

@dataclass
class Camera:
    width: int
    height: int
    zoom: float = 1.25
    x: float = 0
    y: float = WORLD_TOP

    @property
    def visible_width(self):
        return self.width/self.zoom

    @property
    def visible_height(self):
        return self.height/self.zoom

    def follow(self, x, y, dt=0, snap=False):
        target_x = min(max(0, x-self.visible_width/2), max(0, WORLD_WIDTH-self.visible_width))
        target_y = min(max(WORLD_TOP, y-self.visible_height/2), max(WORLD_TOP, WORLD_BOTTOM-self.visible_height))
        weight = 1 if snap else 1-math.exp(-max(0, dt)*10)
        self.x += (target_x-self.x)*weight
        self.y += (target_y-self.y)*weight
        self.x = min(max(0, self.x), max(0, WORLD_WIDTH-self.visible_width))
        self.y = min(max(WORLD_TOP, self.y), max(WORLD_TOP, WORLD_BOTTOM-self.visible_height))

    def sees(self, x, y, margin=70):
        return (self.x-margin <= x <= self.x+self.visible_width+margin
                and self.y-margin <= y <= self.y+self.visible_height+margin)

    def project(self, x, y):
        return (x-self.x)*self.zoom, (y-self.y)*self.zoom

@dataclass
class AmbientActor:
    tag: str
    start: tuple
    end: tuple
    speed: float
    offset: float
    kind: str
    drawn_x: float = 0
    drawn_y: float = 0
    visible: bool = True

    def position(self, elapsed):
        length = max(1, math.dist(self.start, self.end))
        if self.kind == "car":
            # Cars follow one-way lanes. The whole-number part of offset selects
            # direction; wrapping at the road edge makes traffic enter smoothly.
            direction = -1 if self.offset >= 1 else 1
            phase = (elapsed*self.speed/length+self.offset % 1) % 1
            progress = phase if direction > 0 else 1-phase
        else:
            progress = (elapsed*self.speed/length+self.offset) % 2
            progress = progress if progress <= 1 else 2-progress
        x = self.start[0]+(self.end[0]-self.start[0])*progress
        y = self.start[1]+(self.end[1]-self.start[1])*progress
        if self.kind == "pedestrian":
            y += math.sin(elapsed*8+self.offset)*.8
        elif self.kind == "boat":
            y += math.sin(elapsed*.7+self.offset)*1.5
        return x, y

def underground(actor, x, y):
    """Cars vanish between the two portals of the tunnel under the Almada garden."""
    left, _, right, _ = SOUTH_PARK_BOUNDS
    return actor.kind == "car" and left < x < right and in_tunnel(x, y)

