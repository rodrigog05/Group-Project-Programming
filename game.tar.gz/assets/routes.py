from actors import (random, WORLD_WIDTH, WORLD_BOTTOM, RIVER_TOP, RIVER_BOTTOM, south, ROAD_EXCLUSIONS, SOUTH_PARK_BOUNDS, tunnel_covers_y, CAR_SPEED_RANGE, bridge_center, FERRY_PIERS)
def create_actors(self):
    rng = random.Random(2815)
    routes = (((32, 280), (1160, 280)), ((40, 465), (1160, 465)), ((50, 647), (1150, 647)), ((1260, 280), (WORLD_WIDTH - 70, 280)), ((1260, 465), (WORLD_WIDTH - 90, 465)), ((1270, 645), (WORLD_WIDTH - 80, 645)), ((90, south(1090)), (WORLD_WIDTH - 120, south(1090))), ((85, south(1395)), (WORLD_WIDTH - 130, south(1395))), ((65, WORLD_BOTTOM - 55), (WORLD_WIDTH - 110, WORLD_BOTTOM - 55)))
    for index in range(30):
        start, end = routes[index % len(routes)]
        self.actor('pedestrian', start, end, rng.uniform(20, 34), rng.random() * 2, rng.choice(('#b37262', '#547d8b', '#81926f', '#ba9d61', '#8a7195')))
    for index, y in enumerate((291, 308, 476, 493, 650, 666, south(1101), south(1119), south(1362), south(1378), WORLD_BOTTOM - 38, WORLD_BOTTOM - 22)):
        start_x = max([15] + [right + 20 for left, top, right, bottom in ROAD_EXCLUSIONS if top < y < bottom and (not (left == SOUTH_PARK_BOUNDS[0] and tunnel_covers_y(y)))])
        phase_and_direction = rng.random() + index % 2
        self.actor('car', (start_x, y), (WORLD_WIDTH - 20, y), rng.uniform(*CAR_SPEED_RANGE), phase_and_direction, rng.choice(('#9b584e', '#c6c5b5', '#759ca5', '#b89b62')))
    for start, end, speed in (((400, 780), (900, 780), 32), ((1240, 802), (bridge_center(802, True) - 80, 802), 62), ((bridge_center(960, True) + 90, 960), (WORLD_WIDTH - 65, 960), 38), ((430, 835), (870, 835), 20), ((420, 1010), (1100, 1010), 26)):
        self.actor('boat', start, end, speed, rng.random() * 2, '#f2e4c9')
    north_pier, south_pier = FERRY_PIERS
    self.actor('boat', (north_pier.x + 30, RIVER_TOP + 80), (south_pier.x - 30, RIVER_BOTTOM - 80), 45, 0.0, '#e07a2e')
    for index in range(14):
        x = 360 + index * (WORLD_WIDTH - 500) / 13
        y = RIVER_TOP + 32 + index % 6 * (RIVER_BOTTOM - RIVER_TOP - 60) / 6
        self.actor('ripple', (x, y), (x + 60, y), 4, rng.random() * 2, '#b3d5d5')
