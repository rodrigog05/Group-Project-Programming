"""A readable directory of businesses and sights, with destination guidance."""

from dataclasses import dataclass

from lisbon_landmarks import LANDMARKS

from wayfinding import site_guide

from tourism import monument_description, tourism_description

from ferry import FERRY_FARE, FERRY_PIERS, other_pier

from lisbon_scene import south

import businesses

DIRECTORY_TABS = (
    ("buy", "1  Buy materials"),
    ("make", "2  Make products"),
    ("sell", "3  Sell products"),
    ("services", "+  Services"),
    ("landmarks", "◆  Landmarks"),
)

@dataclass(frozen=True)
class DirectoryEntry:
    name: str
    detail: str
    neighborhood: str
    instruction: str
    x: float
    y: float
    marker: str
    color: str

    @property
    def destination(self):
        return self.x, self.y

def neighborhood_for(x, y):
    """Describe this game's compact map, rather than claiming scale geography."""
    if y >= 900:
        if x < 1200:
            return "Almada · Tejo"
        if y >= south(1380):
            return "Palmela"
        return "Seixal" if x >= 1950 else "Cacilhas"
    for edge, name in ((238, "Belém"), (478, "Alcântara"), (718, "Baixa · Chiado"),
                       (958, "Alfama · Graça"), (1220, "Beato"), (1775, "Marvila")):
        if x < edge:
            return name
    return "Parque das Nações"

def destination_for_landmark(landmark):
    left, top, right, bottom = landmark.bounds
    if landmark.kind == "tower":
        # The tower is in the river; guide walkers to the nearby safe promenade.
        return 140, 700
    if landmark.kind == "square":
        return (left+right)/2, (top+bottom)/2
    return (left+right)/2, bottom+18

def directory_entries(sites, landmarks=LANDMARKS, *, town=None):
    """Return directory rows from current site positions; no Tk window is needed."""
    sites = tuple(businesses.effective_site(town, site) if town is not None else site for site in sites)
    rows = {key: [] for key, title in DIRECTORY_TABS}
    for site in sites:
        guide = site_guide(site)
        if guide.stage == "residential":
            continue
        door_x, door_y = site.door
        instruction = " ".join(part for part in (guide.instruction, tourism_description(site)) if part)
        detail = guide.detail
        if town is not None and businesses.is_owned(town, site):
            detail = "Owned · "+detail
            if site.role == "PUBLIC SHOP":
                instruction = ("Press E to stock your shop. Customers buy automatically while demand remains. "
                               "Press B to upgrade, change product, withdraw stock or sell carried goods immediately. ")+tourism_description(site)
            else:
                instruction = (guide.instruction+" This is your factory. Press B to expand storage, upgrade equipment "
                               "or change its product after emptying it and reassigning delivery routes.")
        neighborhood = "Carcavelos" if site.role == "RESEARCH" else neighborhood_for(site.x, site.y)
        entry = DirectoryEntry(site.name, detail, neighborhood,
                               instruction, door_x, door_y+18, guide.marker, guide.color)
        categories = ("make", "sell") if guide.stage == "special" else (guide.stage,)
        for category in categories:
            rows[category].append(entry)
    descriptions = {
        "monastery": ("Manueline monastery · Belém", "Visit the limestone cloister and church façade from the public approach."),
        "castle": ("Castle walls and towers · Alfama", "Visit the hilltop castle's public approach and look for the stone towers."),
        "square": ("Riverside square and arcades", "Walk into the open central courtyard of Praça do Comércio, beside its yellow arcades and statue."),
        "tower": ("Historic riverside tower · Belém", "The tower stands in the Tejo. Guidance leads to the safe north-bank promenade beside it."),
    }
    for landmark in landmarks:
        detail, instruction = descriptions.get(landmark.kind, ("Lisbon landmark", "Explore this Lisbon landmark."))
        x, y = destination_for_landmark(landmark)
        left, top, right, bottom = landmark.bounds
        instruction = " ".join(part for part in (instruction, monument_description(landmark, sites)) if part)
        rows["landmarks"].append(DirectoryEntry(landmark.name, detail, neighborhood_for(left, top),
                                                 instruction, x, y, "◆", "#d5bf76"))
    for pier in FERRY_PIERS:
        rows["services"].append(DirectoryEntry(
            f"Ferry · {pier.name}", f"${FERRY_FARE} to {other_pier(pier).name}", neighborhood_for(pier.x, pier.y),
            f"The bridges carry vehicles only. On foot, walk to the {pier.name} pier and press E to cross the Tejo "
            f"to {other_pier(pier).name} for ${FERRY_FARE}. Your cargo and vehicle come with you.",
            pier.x, pier.y, "F", "#936f22"))
    return {key: tuple(sorted(entries, key=lambda entry: entry.name.casefold())) for key, entries in rows.items()}

